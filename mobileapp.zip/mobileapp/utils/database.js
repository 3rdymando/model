// Example database utility (database.js)

const users = [];  // This is a simple array to simulate a database

// Function to insert a new user into the simulated database
export const insertUser = (username, password, email, phone) => {
  const newUser = { username, password, email, phone };
  users.push(newUser);
  console.log('User added:', newUser);
};

// Function to fetch a user by username
export const getUserByUsername = async (username) => {
  const user = users.find(user => user.username === username);
  return user ? user : null;
};

// Function to validate user login
export const validateLogin = async (username, password) => {
  const user = await getUserByUsername(username);

  if (user && user.password === password) {
    return { success: true, user };
  } else {
    return { success: false, message: 'Invalid username or password' };
  }
};

// Function to update the user information (email, phone, etc.)
export const updateUserInfo = async (username, email, phone) => {
  const user = await getUserByUsername(username);

  if (user) {
    user.email = email || user.email;
    user.phone = phone || user.phone;
    console.log('User updated:', user);
  } else {
    console.warn('User not found.');
  }
};
