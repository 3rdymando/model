import React, { useState } from 'react';
import { View, Text } from 'react-native';
import AudioRecorder from './components/AudioRecorder';

export default function ParentComponent() {
  const [audioUri, setAudioUri] = useState(null); // State for the audio URI

  // Callback to handle the recorded audio URI
  const handleAudioRecorded = (uri) => {
    setAudioUri(uri); // Update the audio URI state
  };

  return (
    <View>
      <AudioRecorder onAudioRecorded={handleAudioRecorded} />
      {audioUri && (
        <Text>Recorded Audio URI: {audioUri}</Text> // Display recorded URI
      )}
    </View>
  );
}
