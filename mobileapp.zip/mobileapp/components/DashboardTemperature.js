import React, { useState, useEffect } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { CircularProgress } from 'react-native-circular-progress';
import { MaterialIcons } from '@expo/vector-icons';

export default function DashboardTemperature({ navigation }) {
  const [temperatureValue, setTemperatureValue] = useState(null);

  useEffect(() => {
    const fetchTemperature = async () => {
      try {
        const response = await fetch('http://192.168.1.23:5000/get_temperature');
        const data = await response.json();

        if (response.ok && data.temperature !== undefined) {
          setTemperatureValue(data.temperature);
        } else {
          Alert.alert('Error', data.error || 'Failed to fetch temperature data');
        }
      } catch (error) {
        Alert.alert('Network Error', 'Could not connect to the server.');
      }
    };

    fetchTemperature();
    const interval = setInterval(fetchTemperature, 5000); // Update every 5 seconds
    return () => clearInterval(interval); // Cleanup interval on component unmount
  }, []);

  let statusColor = '#000'; // Default to black (normal)
  let statusText = 'Normal';

  if (temperatureValue !== null) {
    if (temperatureValue < 33) {
      statusColor = 'blue';
      statusText = 'Low';
    } else if (temperatureValue > 36) {
      statusColor = 'red';
      statusText = 'High';
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.openDrawer()}>
          <MaterialIcons name="menu" size={30} color="#000" />
        </TouchableOpacity>

        <View style={styles.logoContainer}>
          <Image 
            source={{ uri: 'https://i.imghippo.com/files/Oq3Yb1728734281.png' }} 
            style={styles.logo}
          />
          <Text style={styles.headerText}>QBeeTech</Text>
        </View>

        <TouchableOpacity onPress={() => navigation.navigate("UserProfile")}>
          <MaterialIcons name="person" size={50} color="#000" />
        </TouchableOpacity>
      </View>

      <View style={styles.titleContainer}>
        <Text style={styles.typeText}>🌡️ Temperature</Text>
      </View>

      <View style={styles.gaugeContainer}>
        <CircularProgress
          size={250}
          width={20}
          fill={temperatureValue || 0}
          tintColor="#FF4500"
          backgroundColor="#333"
          rotation={180} // Start from the bottom
        >
          {() => (
            <View style={styles.innerGauge}>
              <Text style={styles.gaugeText}>{temperatureValue !== null ? `${temperatureValue}°C` : 'Loading...'}</Text>
              <Text style={styles.iconText}>🔥</Text>
            </View>
          )}
        </CircularProgress>
      </View>

      <Text style={styles.statusText}>
        Status: <Text style={[styles.statusText, { color: statusColor }]}>{statusText}</Text>
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#b58b22',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    paddingHorizontal: 20,
    paddingTop: 70,
    backgroundColor: '#b58b22',
  },
  logoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logo: {
    width: 50,
    height: 50,
  },
  headerText: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#000',
    fontFamily: 'serif',
    marginLeft: 10,
  },
  titleContainer: {
    marginVertical: 10,
    marginTop: 50, 
  },
  typeText: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#000',
  },
  gaugeContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 20,
    marginTop: 30,
  },
  innerGauge: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  gaugeText: {
    fontSize: 30,
    color: '#FFF',
  },
  iconText: {
    fontSize: 30,
    color: '#FF4500',
  },
  statusText: {
    fontSize: 30,
    color: '#000',
    fontWeight: 'bold',
    marginTop: 10,
  },
});