import React, { useState, useEffect } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { registerForPushNotificationsAsync, scheduleNotification } from '../utils/notifications';

export default function DashboardHiveWeight({ navigation }) {
  const [honeyWeight, setHoneyWeight] = useState(25);
  const goalWeight = 25; // Goal weight remains constant

  // Register for notifications on component mount
  useEffect(() => {
    registerForPushNotificationsAsync();
  }, []);

  // Schedule local notification if weight reaches or exceeds the goal
  useEffect(() => {
    if (honeyWeight >= goalWeight) {
      scheduleNotification(
        'Goal Reached!',
        `The honey weight has reached the goal of ${goalWeight} lbs!`
      );
    }
  }, [honeyWeight]);

  // Simulate weight updates
  useEffect(() => {
    const interval = setInterval(() => {
      const randomHoneyWeight = (Math.random() * (25 - 5) + 5).toFixed(2);
      setHoneyWeight(parseFloat(randomHoneyWeight)); // Convert string back to float
    }, 2000);

    return () => clearInterval(interval); // Cleanup on component unmount
  }, []);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.openDrawer()}>
          <MaterialIcons name="menu" size={30} color="#000" />
        </TouchableOpacity>

        <View style={styles.logoContainer}>
          <Image
            source={{ uri: 'https://i.imghippo.com/files/Oq3Yb1728734281.png' }}
            style={styles.logo}
          />
          <Text style={styles.headerText}>QBeeTech</Text>
        </View>

        <TouchableOpacity onPress={() => navigation.navigate('UserProfile')}>
          <MaterialIcons name="person" size={50} color="#000" />
        </TouchableOpacity>
      </View>

      <View style={styles.titleContainer}>
        <Text style={styles.typeText}>Honey Weight</Text>
      </View>

      <Text style={styles.weight}>{honeyWeight} lbs</Text>
      <Text style={styles.goal}>Goal: {goalWeight} lbs</Text>
      <Text style={styles.percentage}>Percentage: {(honeyWeight / goalWeight * 100).toFixed(1)}%</Text>

      <View style={styles.logContainer}>
        <View style={styles.logTitles}>
          <Text style={styles.logTitleText}>Weight</Text>
          <Text style={styles.logTitleText}>Time</Text>
        </View>

        <View style={styles.logItem}>
          <Text style={styles.logText}>+ 0.4 lbs</Text>
          <Text style={styles.logDate}>Nov 5, 2024</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#b58b22',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    paddingHorizontal: 20,
    paddingTop: 70,
    backgroundColor: '#b58b22',
  },
  logoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logo: {
    width: 50,
    height: 50,
  },
  headerText: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#000',
    fontFamily: 'serif',
    marginLeft: 10,
  },
  titleContainer: {
    marginVertical: 10,
    marginTop: 50,
  },
  typeText: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#000',
  },
  weight: {
    fontSize: 40,
    fontWeight: 'bold',
    color: '#000',
    marginVertical: 15,
  },
  goal: {
    fontSize: 20,
    color: '#000',
    marginVertical: 15,
  },
  percentage: {
    fontSize: 20,
    color: '#000',
  },
  logContainer: {
    marginTop: 50,
    width: '90%',
    backgroundColor: '#FFF',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  logTitles: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    paddingBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#b58b22',
    marginBottom: 10,
  },
  logTitleText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#b58b22',
  },
  logItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    paddingVertical: 10,
  },
  logText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#b58b22',
  },
  logDate: {
    fontSize: 20,
    color: '#000',
  },
});
