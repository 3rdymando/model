import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, Alert } from 'react-native';
import { Audio } from 'expo-av';
import { predictAudio } from '../utils/prediction'; // Assuming prediction logic is in utils

export default function AudioRecorder() {
  const [recording, setRecording] = useState(null);
  const [message, setMessage] = useState('Recording...');
  const [prediction, setPrediction] = useState(null);

  // Memoized startRecording function
  const startRecording = useCallback(async () => {
    try {
      const { status } = await Audio.requestPermissionsAsync();
      if (status !== 'granted') {
        setMessage('Permission to access the microphone is required!');
        return;
      }

      await Audio.setAudioModeAsync({
        allowsRecordingIOS: true,
        playsInSilentModeIOS: true,
      });

      // Start recording
      const { recording } = await Audio.Recording.createAsync(
        Audio.RECORDING_OPTIONS_PRESET_HIGH_QUALITY
      );
      setRecording(recording);
      setMessage('Recording...');
    } catch (error) {
      console.error('Failed to start recording:', error);
      setMessage('Error starting recording.');
    }
  }, []);

  // Memoized stopRecording function
  const stopRecording = useCallback(async () => {
    try {
      if (recording) {
        await recording.stopAndUnloadAsync();
        setRecording(null);
        setMessage('Recording stopped!');
      }
    } catch (error) {
      console.error('Failed to stop recording:', error);
      setMessage('Error stopping recording.');
    }
  }, [recording]);

  // Continuous prediction while recording
  const recordAndPredict = useCallback(async () => {
    if (recording) {
      const uri = recording.getURI();
      // Perform prediction on the recorded audio
      const predictionResult = await predictAudio(uri); // Use your prediction logic
      setPrediction(predictionResult); // Set prediction result to display

      // Show the prediction in an alert
      Alert.alert('Prediction Result', predictionResult);

      // Add a small delay (e.g., 1 second) before next prediction
      setTimeout(() => {
        recordAndPredict(); // Call again to continue prediction loop
      }, 1000); // Adjust as needed (1000ms = 1 second)
    }
  }, [recording]);

  // Start recording automatically when the component mounts
  useEffect(() => {
    startRecording();
    return () => stopRecording(); // Clean up when the component is unmounted
  }, [startRecording, stopRecording]); // Add memoized functions to dependencies

  // Continuously predict when recording is active
  useEffect(() => {
    if (recording) {
      recordAndPredict();
    }
  }, [recording, recordAndPredict]);

  return (
    <View>
      <Text>{message}</Text>
      {/* Optionally, you can still display the prediction result in the UI */}
      <Text>Prediction Result: {prediction}</Text>
    </View>
  );
}
