// ./components/DashboardHumidity.js
import React, { useState, useEffect } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';
import { CircularProgress } from 'react-native-circular-progress';
import { MaterialIcons } from '@expo/vector-icons';
import axios from 'axios'; // Import axios for API requests

export default function DashboardHumidity({ navigation }) {
  const [humidityValue, setHumidityValue] = useState(50);

  useEffect(() => {
    // Fetch humidity from Flask server every 2 seconds
    const interval = setInterval(() => {
      axios.get('http://192.168.1.23:5000/get_humidity')  // Replace with your Flask server IP
        .then(response => {
          if (response.data.humidity) {
            setHumidityValue(response.data.humidity);
          }
        })
        .catch(error => {
          console.error("Error fetching humidity:", error);
        });
    }, 2000); // Update every 2 seconds

    return () => clearInterval(interval); // Cleanup the interval on component unmount
  }, []);

  // Determine the status color and text based on the humidity value
  let statusColor = '#000'; // Default to black (normal)
  let statusText = 'Normal';

  if (humidityValue < 50) {
    statusColor = 'blue'; // Low humidity
    statusText = 'Low';
  } else if (humidityValue > 60) {
    statusColor = 'red'; // High humidity
    statusText = 'High';
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.openDrawer()}>
          <MaterialIcons name="menu" size={30} color="#000" />
        </TouchableOpacity>
        
        <View style={styles.logoContainer}>
          <Image 
            source={{ uri: 'https://i.imghippo.com/files/Oq3Yb1728734281.png' }} 
            style={styles.logo}
          />
          <Text style={styles.headerText}>QBeeTech</Text>
        </View>

        <TouchableOpacity onPress={() => navigation.navigate("UserProfile")}>
          <MaterialIcons name="person" size={50} color="#000" />
        </TouchableOpacity>
      </View>

      <View style={styles.titleContainer}>
        <Text style={styles.typeText}>💧 Humidity</Text>
      </View>
      
      <View style={styles.gaugeContainer}>
        <CircularProgress
          size={250}
          width={20}
          fill={humidityValue}
          tintColor="#1E90FF"
          backgroundColor="#333"
          rotation={180} // Start from the bottom
        >
          {() => (
            <View style={styles.innerGauge}>
              <Text style={styles.gaugeText}>{humidityValue}%</Text>
              <Text style={styles.iconText}>💧</Text>
            </View>
          )}
        </CircularProgress>
      </View>
        <Text style={styles.statusText}>Status:
        <Text> </Text>
        <Text style={[styles.statusText, { color: statusColor }]}>{statusText}</Text>
        </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#b58b22',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    paddingHorizontal: 20,
    paddingTop: 70,
    backgroundColor: '#b58b22',
  },
  logoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logo: {
    width: 50,
    height: 50,
  },
  headerText: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#000',
    fontFamily: 'serif',
    marginLeft: 10,
  },
  titleContainer: {
    marginVertical: 10,
    marginTop: 50, 
  },
  typeText: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#000',
  },
  gaugeContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 20,
    marginTop: 30,
  },
  innerGauge: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  gaugeText: {
    fontSize: 30,
    color: '#FFF',
  },
  iconText: {
    fontSize: 30,
    color: '#1E90FF',
  },
  statusText: {
    fontSize: 30,
    color: '#000',
    fontWeight: 'bold',
    marginTop: 10,
  },
});