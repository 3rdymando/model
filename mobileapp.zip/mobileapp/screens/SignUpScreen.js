import React, { useState } from 'react';
import { View, Text, Image, TextInput, TouchableOpacity, StyleSheet } from 'react-native';

export default function SignUpScreen({ navigation }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');

  const handleSignUp = () => {
    alert('Account created successfully');
    navigation.navigate('Login'); 
  };

  return (
    <View style={styles.container}>
      <View style={styles.logoContainer}>
        <Image 
          source={{ uri: 'https://i.imghippo.com/files/Oq3Yb1728734281.png' }} 
          style={styles.logo}
        />
      <Text style={styles.headerText}>QBeeTech</Text>
    </View>
      <Text style={styles.title}>Sign Up</Text>
      <TextInput 
        placeholder="Username" 
        style={styles.input} 
        value={username}
        onChangeText={setUsername}
      />
      <TextInput 
        placeholder="Password" 
        style={styles.input} 
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      <TextInput 
        placeholder="Email" 
        style={styles.input} 
        value={email}
        onChangeText={setEmail}
      />
      <TouchableOpacity style={styles.button} onPress={handleSignUp}>
        <Text style={styles.buttonText}>Sign Up</Text>
      </TouchableOpacity>

        <View style={styles.textContainer}>
          <Text style={styles.text}>Already have an account? </Text>
        <TouchableOpacity>
          <Text style={styles.loginText} 
          onPress={() => navigation.navigate('Login')}>Login</Text>
        </TouchableOpacity>
        </View>


    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#b58b22',
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 50,
  },
  logo: {
    width: 150,
    height: 150,
    marginTop: -50,
    marginBottom: 5,
    borderRadius:25,
  },  
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginTop: 25,
    marginBottom: 20,
  },
  headerText: {
    fontSize: 25,
    fontWeight: 'bold',
    color: '#000',
    fontFamily: 'serif',
  },
  input: {
    width: '80%',
    backgroundColor: '#e0e0e0',
    marginVertical: 8,
    padding: 10,
    borderRadius: 5,
  },
  button: {
    backgroundColor: '#000',
    padding: 10,
    width: '80%',
    borderRadius: 5,
    alignItems: 'center',
    marginTop: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  textContainer: { 
    flexDirection: 'row',     
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 10,
  },
  text: {
    fontSize: 16,
    color: '#000',
  },
  loginText: {
    fontSize: 16,
    color: '#0000FF',   
  },
});