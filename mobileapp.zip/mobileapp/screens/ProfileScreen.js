import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

export default function ProfileScreen({ navigation, route }) {
  const { setIsLoggedIn } = route.params || {};  
  
  const handleLogout = () => {
    if (setIsLoggedIn) {
      setIsLoggedIn(false);
      navigation.navigate("Login");  
    } else {
      alert("Error: setIsLoggedIn not available.");
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.openDrawer()}>
          <MaterialIcons name="menu" size={30} color="#000" />
        </TouchableOpacity>

        <View style={styles.logoContainer}>
          <Image 
            source={{ uri: 'https://i.imghippo.com/files/Oq3Yb1728734281.png' }} 
            style={styles.logo}
          />
          <Text style={styles.headerText}>QBeeTech</Text>
        </View>
      </View>

      <Text style={styles.title}>User Profile</Text>
      <MaterialIcons name="person" size={150} color="#000" />
      <Text style={styles.username}>Team 50</Text>
      
      <TouchableOpacity>
        <Text style={styles.link}>Change profile</Text>
      </TouchableOpacity>
      
      <TouchableOpacity>
        <Text style={styles.link}>Change password</Text>
      </TouchableOpacity>
      
      <Text style={styles.email}>Email: team50@gmail.com</Text>
      <Text style={styles.phone}>Phone: 09123456789</Text>

      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
        <Text style={styles.logoutText}>Log Out</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#b58b22',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    paddingHorizontal: 20,
    paddingTop: 70,
    backgroundColor: '#b58b22',
  },
  logoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 0.6,
    marginRight: 106,
  },
  logo: {
    width: 50,
    height: 50,
  },
  headerText: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#000',
    fontFamily: 'serif',
    marginLeft: 10,
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#000',
    marginVertical: 50,
  },
  username: {
    fontSize: 25,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 50,
  },
  link: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 20,
  },
  email: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
    marginTop: 40,
  },
  phone: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
    marginTop: 20,
  },
  logoutButton: {
    marginTop: 30,
    paddingVertical: 15,
    paddingHorizontal: 50,
    backgroundColor: 'red',
    borderRadius: 20,
    position: 'absolute',
    bottom: 50,
  },
  logoutText: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});