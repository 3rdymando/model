import React, { useState } from 'react';
import { View, Text, Image, TextInput, TouchableOpacity, StyleSheet } from 'react-native';

export default function LoginScreen({ navigation, setIsLoggedIn }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

const handleLogin = () => {
    setIsLoggedIn(true); 
    navigation.navigate('Temperature'); 
};

  return (
    <View style={styles.container}>
      <View style={styles.logoContainer}>
        <Image 
          source={{ uri: 'https://i.imghippo.com/files/Oq3Yb1728734281.png' }} 
          style={styles.logo}
        />
      <Text style={styles.headerText}>QBeeTech</Text>
    </View>

      <Text style={styles.title}>Login</Text>
      <TextInput 
        placeholder="Username" 
        style={styles.input} 
        value={username}
        onChangeText={setUsername}
      />
      <TextInput 
        placeholder="Password" 
        style={styles.input} 
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      <TouchableOpacity style={styles.button} onPress={handleLogin}>
        <Text style={styles.buttonText}>Login</Text>
      </TouchableOpacity>  
      
        <View style={styles.textContainer}>
          <Text style={styles.text}>Don't have an account? </Text>
        <TouchableOpacity>
          <Text style={styles.signUpText} 
          onPress={() => navigation.navigate('SignUp')}>Sign Up</Text>
        </TouchableOpacity>
        </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#b58b22',
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 100,
  },
  logo: {
    width: 150,
    height: 150,
    marginTop: -100,
    marginBottom: 5,
    borderRadius:25,
  },  
  headerText: {
    fontSize: 25,
    fontWeight: 'bold',
    color: '#000',
    fontFamily: 'serif',
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginTop: -40,
    marginBottom: 20,
    color: '#000', 
  },
  input: {
    width: '80%',
    backgroundColor: '#e0e0e0',
    marginVertical: 8,
    padding: 10,
    borderRadius: 5,
    fontSize: 16,
  },
  button: {
    backgroundColor: '#000',
    padding: 10,
    width: '80%',
    borderRadius: 5,
    alignItems: 'center',
    marginTop: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  textContainer: { 
    flexDirection: 'row',     
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 10,
  },
  text: {
    fontSize: 16,
    color: '#000',
  },
  signUpText: {
    fontSize: 16,
    color: '#0000FF',   
  },
});