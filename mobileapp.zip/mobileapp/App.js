import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createStackNavigator } from '@react-navigation/stack';
import LoginScreen from './screens/LoginScreen';
import SignUpScreen from './screens/SignUpScreen'; 
import ProfileScreen from './screens/ProfileScreen';
import DashboardTemperature from './components/DashboardTemperature';
import DashboardHumidity from './components/DashboardHumidity';
import DashboardHiveWeight from './components/DashboardHiveWeight';

const Drawer = createDrawerNavigator();
const Stack = createStackNavigator();

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const AppDrawer = () => (
    <Drawer.Navigator
      initialRouteName="Temperature"
      screenOptions={{
        drawerStyle: {
          backgroundColor: '#b58b22',
          width: '60%',
        },
        headerShown: false,
      }}
    >
      <Drawer.Screen 
        name="UserProfile" 
        component={ProfileScreen} 
        options={{
          title: 'Profile', 
          headerShown: false,
          drawerItemStyle: {
            display: 'none',  // Hide the profile item completely
          },
        }}
        initialParams={{ setIsLoggedIn }}
      />
      <Drawer.Screen 
        name="Temperature" 
        component={DashboardTemperature} 
        options={{ title: 'Temperature' }} 
        initialParams={{ setIsLoggedIn }}
      />
      <Drawer.Screen 
        name="Humidity" 
        component={DashboardHumidity} 
        options={{ title: 'Humidity' }} 
      />
      <Drawer.Screen 
        name="HoneyWeight" 
        component={DashboardHiveWeight} 
        options={{ title: 'Honey Weight' }} 
      />
    </Drawer.Navigator>
  );

  const AuthStack = () => (
    <Stack.Navigator initialRouteName="Login">
      <Stack.Screen
        name="Login"
        options={{ headerShown: false }}
      >
        {(props) => <LoginScreen {...props} setIsLoggedIn={setIsLoggedIn} />}
      </Stack.Screen>
      <Stack.Screen
        name="SignUp"
        component={SignUpScreen} 
        options={{ headerShown: false }}
      />
    </Stack.Navigator>
  );

  return (
    <NavigationContainer>
      {isLoggedIn ? <AppDrawer /> : <AuthStack />}
    </NavigationContainer>
  );
}